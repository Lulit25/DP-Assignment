/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package no_2_overide;

/**
 *
 * @author Lulit
 */
public class product {
      // This product takes two int parameters 
    public int product(int x, int y) 
    { 
        return (x * y); 
    } 
    //This product takes two double parameters 
    public double product(double x, double y) 
    { 
        return (x * y); 
    } 
   // This product takes three int parameters 
    public int product(int x, int y, int z) 
    { 
        return (x * y * z); 
    } 
  
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package no_2_overide;

/**
 *
 * @author Lulit
 */
public class No_2_overide extends product {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           product p = new product(); 
        System.out.println(p.product(4, 5)); 
        System.out.println(p.product(4.5, 6.5)); 
        System.out.println(p.product(4, 5, 6)); 
    }
    // Java program to demonstrate working of method 
// overloading in Java. 
//Here the product() method is overloaded.


}